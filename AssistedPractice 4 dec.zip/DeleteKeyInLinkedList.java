package RightRotateArray;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public LinkedList() {
        this.head = null;
    }

    // Function to insert a new node at the end of the linked list
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Function to display the linked list
    public void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    // Function to delete the first occurrence of a key in the linked list
    public void deleteKey(int key) {
        Node current = head;
        Node prev = null;

        // Check if the key is present in the head node
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key in the remaining nodes
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is not present in the linked list
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Delete the node with the key
        prev.next = current.next;
    }
}

public class DeleteKeyInLinkedList {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        // Insert elements into the linked list
        linkedList.insert(10);
        linkedList.insert(20);
        linkedList.insert(30);
        linkedList.insert(40);

        System.out.println("Original linked list:");
        linkedList.display();

        // Delete the first occurrence of a key (e.g., 20)
        int keyToDelete = 20;
        linkedList.deleteKey(keyToDelete);

        System.out.println("Linked list after deleting the first occurrence of " + keyToDelete + ":");
        linkedList.display();
    }
}