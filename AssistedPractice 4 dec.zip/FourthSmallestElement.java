package RightRotateArray;

import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {12, 5, 8, 10, 15, 2, 7, 6}; // Example unsorted list
        int fourthSmallest = findFourthSmallest(unsortedList);

        System.out.println("The fourth smallest element in the unsorted list is: " + fourthSmallest);
    }

    // Function to find the fourth smallest element in an unsorted list
    private static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List has less than four elements.");
            return -1; // Return -1 to indicate that there is no fourth smallest element
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // Return the fourth element (index 3) in the sorted array
        return arr[3];
    }
}