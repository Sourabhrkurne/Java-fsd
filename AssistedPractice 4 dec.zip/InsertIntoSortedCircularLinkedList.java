package RightRotateArray;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    public CircularLinkedList() {
        this.head = null;
    }

    // Function to insert a new node into a sorted circular linked list
    public void insertSorted(int newData) {
        Node newNode = new Node(newData);
        Node current = head;

        // If the list is empty, make the new node the head and point it to itself
        if (current == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (newData <= current.data) {
            // If the new data is smaller than or equal to the head data, insert at the beginning
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Find the appropriate position to insert the new node
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }

            // Insert the new node into the sorted position
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Function to display the circular linked list
    public void display() {
        Node current = head;
        if (current != null) {
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
            System.out.println();
        }
    }
}

public class InsertIntoSortedCircularLinkedList {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList();

        // Insert elements into the sorted circular linked list
        circularList.insertSorted(10);
        circularList.insertSorted(20);
        circularList.insertSorted(30);
        circularList.insertSorted(40);

        System.out.println("Original sorted circular linked list:");
        circularList.display();

        // Insert a new element (e.g., 25) into the sorted circular linked list
        int newData = 25;
        circularList.insertSorted(newData);

        System.out.println("Sorted circular linked list after inserting " + newData + ":");
        circularList.display();
    }
}