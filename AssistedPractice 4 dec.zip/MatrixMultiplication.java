package RightRotateArray;

import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input matrix A
        System.out.print("Enter the number of rows in matrix A: ");
        int rowsA = scanner.nextInt();
        System.out.print("Enter the number of columns in matrix A: ");
        int colsA = scanner.nextInt();
        int[][] matrixA = inputMatrix(rowsA, colsA, "A", scanner);

        // Input matrix B
        System.out.print("Enter the number of rows in matrix B: ");
        int rowsB = scanner.nextInt();
        System.out.print("Enter the number of columns in matrix B: ");
        int colsB = scanner.nextInt();
        int[][] matrixB = inputMatrix(rowsB, colsB, "B", scanner);

        // Check if multiplication is possible
        if (colsA != rowsB) {
            System.out.println("Matrix multiplication is not possible. The number of columns in A must be equal to the number of rows in B.");
        } else {
            // Perform matrix multiplication
            int[][] resultMatrix = multiplyMatrices(matrixA, matrixB);

            // Display the result matrix
            System.out.println("Resultant Matrix:");
            displayMatrix(resultMatrix);
        }

        scanner.close();
    }

    // Function to input a matrix from the user
    private static int[][] inputMatrix(int rows, int cols, String matrixName, Scanner scanner) {
        System.out.println("Enter the elements of matrix " + matrixName + ":");
        int[][] matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print("Enter element at position (" + (i + 1) + ", " + (j + 1) + "): ");
                matrix[i][j] = scanner.nextInt();
            }
        }
        return matrix;
    }

    // Function to multiply two matrices
    private static int[][] multiplyMatrices(int[][] A, int[][] B) {
        int rowsA = A.length;
        int colsA = A[0].length;
        int colsB = B[0].length;

        int[][] result = new int[rowsA][colsB];

        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                for (int k = 0; k < colsA; k++) {
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        return result;
    }

    // Function to display a matrix
    private static void displayMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
    }
}