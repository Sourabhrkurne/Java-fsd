package RightRotateArray;

import java.util.Scanner;

public class SumInRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();

        // Input array
        int[] array = new int[n];
        System.out.println("Enter the array elements:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        System.out.print("Enter the range (L and R, where 0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();

        // Check if the input range is valid
        if (L < 0 || R < L || R >= n) {
            System.out.println("Invalid range.");
        } else {
            // Calculate the sum of elements in the specified range
            int sumInRange = calculateSumInRange(array, L, R);
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);
        }

        scanner.close();
    }

    // Function to calculate the sum of elements in the range [L, R]
    private static int calculateSumInRange(int[] arr, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}