package RightRotateArray;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.add(10);
        queue.add(20);
        queue.add(30);

        System.out.println("Queue after enqueuing elements: " + queue);

        // Dequeue elements from the queue
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued element: " + dequeuedElement);
        System.out.println("Queue after dequeuing: " + queue);

        // Peek at the front element without removing it
        int frontElement = queue.peek();
        System.out.println("Front element without removing: " + frontElement);
        System.out.println("Queue after peeking: " + queue);
    }
}
