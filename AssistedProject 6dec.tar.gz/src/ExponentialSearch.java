public class ExponentialSearch {

    // Function to perform binary search within a given range
    static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1; // Return -1 if the target is not found
    }

    // Function to perform exponential search
    static int exponentialSearch(int[] arr, int target) {
        int n = arr.length;

        // Find the range where the target may be present
        int bound = 1;
        while (bound < n && arr[bound] < target) {
            bound *= 2;
        }

        // Perform binary search within the identified range
        int left = bound / 2;
        int right = Math.min(bound, n - 1);

        return binarySearch(arr, target, left, right);
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 5, 7, 8, 10};
        int target = 7;

        int result = exponentialSearch(arr, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }
    }
}