class SharedResource {
    boolean isDataReady = false;
    
    synchronized void produceData() {
        // Simulate some time-consuming task
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Produce data
        System.out.println("Data produced.");
        isDataReady = true;
        
        // Notify waiting threads
        notify();
    }
    
    synchronized void consumeData() {
        // Wait until data is ready
        while (!isDataReady) {
            try {
                System.out.println("Consumer waiting for data...");
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        // Consume data
        System.out.println("Data consumed.");
    }
}

public class SleepAndWaitDemo {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();
        
        // Producer thread
        Thread producerThread = new Thread(() -> {
            sharedResource.produceData();
        });
        
        // Consumer thread
        Thread consumerThread = new Thread(() -> {
            sharedResource.consumeData();
        });
        
        // Start the threads
        producerThread.start();
        consumerThread.start();
        
        // Wait for both threads to finish
        try {
            producerThread.join();
            consumerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("Program completed.");
    }
}
