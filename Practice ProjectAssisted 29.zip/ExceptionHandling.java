class CustomException extends Exception {
    // Custom exception class
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionHandling {
    // Method that throws an exception using 'throws'
    public static void methodWithThrows(int value) throws CustomException {
        if (value < 0) {
            throw new CustomException("Value cannot be negative");
        }
        System.out.println("Value is: " + value);
    }

    // Method that throws an exception using 'throw'
    public static void methodWithThrow(int value) {
        if (value == 0) {
            throw new IllegalArgumentException("Value cannot be zero");
        }
        System.out.println("Value is: " + value);
    }

    public static void main(String[] args) {
        try {
            // Call a method that throws an exception using 'throws'
            methodWithThrows(-5);
        } catch (CustomException e) {
            System.err.println("Caught CustomException: " + e.getMessage());
        } finally {
            System.out.println("This block always executes.");
        }

        try {
            // Call a method that throws an exception using 'throw'
            methodWithThrow(0);
        } catch (IllegalArgumentException e) {
            System.err.println("Caught IllegalArgumentException: " + e.getMessage());
        } finally {
            System.out.println("This block always executes.");
        }
    }
}
