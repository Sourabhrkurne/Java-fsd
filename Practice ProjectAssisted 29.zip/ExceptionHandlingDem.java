import java.util.Scanner;

public class ExceptionHandlingDem
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Try to perform some operations that might throw exceptions
            System.out.print("Enter the numerator: ");
            int numerator = scanner.nextInt();

            System.out.print("Enter the denominator: ");
            int denominator = scanner.nextInt();

            // Division operation that may cause ArithmeticException
            int result = numerator / denominator;

            // ArrayIndexOutOfBoundsException
            int[] array = { 1, 2, 3 };
            System.out.println("Element at index 3: " + array[3]);

        } catch (ArithmeticException e) {
            // Catch ArithmeticException (e.g., division by zero)
            System.err.println("ArithmeticException: " + e.getMessage());

        } catch (ArrayIndexOutOfBoundsException e) {
            // Catch ArrayIndexOutOfBoundsException
            System.err.println("ArrayIndexOutOfBoundsException: " + e.getMessage());

        } catch (Exception e) {
            // Catch any other exception
            System.err.println("An unexpected error occurred: " + e.getMessage());

        } finally {
            // The code in the finally block always executes, whether an exception occurs or not
            System.out.println("Finally block: This will always execute.");

            // Close the scanner in the finally block to ensure it gets closed
            scanner.close();
        }

        // This code will execute after the try-catch-finally block
        System.out.println("Program completed.");
    }
}

