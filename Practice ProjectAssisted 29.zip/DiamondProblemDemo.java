interface Animal {
    void makeSound();
}

interface Mammal extends Animal {
    void giveBirth();
}

interface Bird extends Animal {
    void layEggs();
}

// Diamond problem resolved by using interfaces
class Platypus implements Mammal, Bird {
    @Override
    public void makeSound() {
        System.out.println("Platypus makes a unique sound.");
    }

    @Override
    public void giveBirth() {
        System.out.println("Platypus gives birth to live young.");
    }

    @Override
    public void layEggs() {
        System.out.println("Platypus lays eggs.");
    }
}

public class DiamondProblemDemo {
    public static void main(String[] args) {
        Platypus platypus = new Platypus();

        // Calling methods to demonstrate resolution of the diamond problem
        platypus.makeSound();
        platypus.giveBirth();
        platypus.layEggs();
    }
}
