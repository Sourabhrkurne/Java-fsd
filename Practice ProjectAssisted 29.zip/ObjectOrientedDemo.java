// Class representing a basic shape
class Shape {
    // Attributes
    protected String color;

    // Constructor
    public Shape(String color) {
        this.color = color;
    }

    // Method to get the color
    public String getColor() {
        return color;
    }

    // Method to calculate area (to be overridden by subclasses)
    public double calculateArea() {
        return 0.0;
    }
}

// Subclass representing a Circle
class Circle extends Shape {
    // Additional attribute
    private double radius;

    // Constructor
    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

    // Override method to calculate area for a Circle
    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

// Subclass representing a Rectangle
class Rectangle extends Shape {
    // Additional attributes
    private double length;
    private double width;

    // Constructor
    public Rectangle(String color, double length, double width) {
        super(color);
        this.length = length;
        this.width = width;
    }

    // Override method to calculate area for a Rectangle
    @Override
    public double calculateArea() {
        return length * width;
    }
}

public class ObjectOrientedDemo {
    public static void main(String[] args) {
        // Creating objects
        Circle redCircle = new Circle("Red", 5.0);
        Rectangle blueRectangle = new Rectangle("Blue", 4.0, 6.0);

        // Accessing attributes
        System.out.println("Circle color: " + redCircle.getColor());
        System.out.println("Rectangle color: " + blueRectangle.getColor());

        // Accessing methods and polymorphism
        System.out.println("Circle area: " + redCircle.calculateArea());
        System.out.println("Rectangle area: " + blueRectangle.calculateArea());

        // Demonstrating encapsulation
        // Note: The 'color' attribute is protected, but it can't be accessed directly in this class.
    }
}
