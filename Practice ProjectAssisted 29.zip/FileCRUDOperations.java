import java.io.*;

public class FileCRUDOperations {
    private static final String FILE_PATH = "sample.txt";

    public static void main(String[] args) {
        // Create operation
        createFile();

        // Read operation
        readFile();

        // Update operation
        updateFile();

        // Read updated file
        readFile();

        // Delete operation
        deleteFile();
    }

    // Create operation
    private static void createFile() {
        try {
            FileWriter writer = new FileWriter(FILE_PATH);
            writer.write("Hello, this is a sample file content.");
            writer.close();
            System.out.println("File created successfully.");
        } catch (IOException e) {
            System.err.println("Error creating the file: " + e.getMessage());
        }
    }

    // Read operation
    private static void readFile() {
        try {
            FileReader reader = new FileReader(FILE_PATH);
            BufferedReader bufferedReader = new BufferedReader(reader);

            System.out.println("File content:");
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

            bufferedReader.close();
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    // Update operation
    private static void updateFile() {
        try {
            FileWriter writer = new FileWriter(FILE_PATH, true); // Append mode
            writer.write("\nThis line is added for the update operation.");
            writer.close();
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }
    }

    // Delete operation
    private static void deleteFile() {
        File file = new File(FILE_PATH);
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.err.println("Error deleting the file.");
        }
    }
}
