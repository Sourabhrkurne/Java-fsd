import java.util.Scanner;

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        try {
            // Try to read an integer from the user
            int number = scanner.nextInt();

            // Perform some operation with the entered number
            int result = 10 / number;

            // Display the result
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch division by zero exception
            System.err.println("Error: Division by zero is not allowed.");
        } catch (Exception e) {
            // Catch any other exception
            System.err.println("An error occurred: " + e.getMessage());
        } finally {
            // Close the scanner in the finally block to ensure it gets closed
            scanner.close();
        }
    }
}
