import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailValidator {

    public static void main(String[] args) {
        // Example email addresses for testing
        String[] emails = {
            "user@example.com",
            "john.doe123@company.org",
            "invalid.email",
            "missing@dotcom"
        };

        // Regular expression for email validation
        String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$";

        // Creating a Pattern object
        Pattern pattern = Pattern.compile(emailRegex);

        // Checking each email address against the pattern
        for (String email : emails) {
            Matcher matcher = pattern.matcher(email);
            if (matcher.matches()) {
                System.out.println(email + " is a valid email address.");
            } else {
                System.out.println(email + " is not a valid email address.");
            }
        }
    }
}